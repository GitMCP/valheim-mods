# Njord, Warehouse Keeper

Njord is a warehouse keeper you place with the hammer. Talk to him, and the
items in nearby chests appear together. Take a stack from the list and it comes
out of the chest it actually sits in. Deposit, and it goes to an existing pile
of the same thing, or into the first empty slot the network has.

He keeps no goods of his own. If nowhere nearby will take what you send, it
stays in your pack.

Because he is a buildable piece, the mod must be installed on the **server and
on every client**. A client whose version does not match the server's is refused.

If [EpicLoot](https://github.com/OrianaVenture/Randy_Vapok_ValheimMods/tree/main/EpicLoot)
is also installed, listed magic items, runestones, and crafting materials tint
the row with that mod's rarity colour. The inventory slot frame is not drawn
on Njord's list. EpicLoot is optional.

## Installation

Drop `NjordWarehouseKeeper.dll` into `BepInEx/plugins`, or install the zip with a
mod manager. Requires [Jötunn](https://thunderstore.io/c/valheim/p/ValheimModding/Jotunn/).

## Source

The source is on [GitHub](https://github.com/GitMCP/valheim-mods). The mod is
open: if you want to fix something, change how it works, or help maintain it,
open a pull request or an issue. You do not need to ask first.

## Building one

| Cost | Where |
| --- | --- |
| 200 gold coins | Hammer, Furniture |

No workbench, and no other materials. Place him like any furniture. He stands
where you put him, starts in a leather tunic and pants, and will remark on
the stores now and then the way a vendor does. Dress him from the item list,
cycle his pose with **R**, and he will look toward whoever is nearest.

## Using it

Walk up and press use. Your inventory stays on the left. Vanilla crafting on the
right is hidden; Njord's recipe panel opens in that slot, and his item list
opens in the center. The cog still opens Preferences. Identical items from
different chests share one row. Hover a row the same way you hover a pack
slot: keep the cursor still for a moment and the vanilla item tooltip appears
in front of the list, so the scroll mask does not crop it.

- **Click a row** to pick up one stack and drag it, the same as a chest slot.
  If the stores have enough to fill a complete stack, that is what you pick up,
  not a leftover pile from the first chest that happens to hold some.
- **Ctrl-click a row** to take as much of that item as your pack will hold.
- **Shift-click a row** to pick how many to take.
- **Click the star** on a listed row, or on an item in your own pack, to mark
  that item as a favourite. Weapons, armour, and tools star as that specific
  piece; stacking goods still share one star. The pack star is there whenever
  inventory is open (Tab included), not only while talking to Njord. The
  Favourites category lists only starred items. The star next to the sort
  buttons filters the current category the same way.
- **Click the dress button** on an equipable listed item (the Hildir dress
  icon, upper-right of the item icon) to make Njord wear that piece. The item
  stays in the chest and can still be taken. He wears one item per slot;
  dressing another helmet, chest, cape, or weapon replaces the last. Click
  the same button again to take that piece off. Leather is the fallback
  when a slot is empty.
- **Press R** while talking to Njord or hovering him to cycle poses: weapons
  sheathed on his back, weapons drawn, sitting, and flexing. The hover text
  shows the current pose.
- His head turns toward the nearest player in range. From time to time he
  waves, flexes, cheers, or otherwise fidgets without leaving the spot.
- **Click an item in your inventory**, then click the panel (or a row) to
  store it. Dropping on a row stores the dragged item; it does not withdraw.
- **Shift-click** an item in your inventory, or press **Deposit**, to send it
  into the network. The hotbar is left alone unless you turn that on in config.
- **Resupply** fills your pack from nearby chests up to the counts set in Preferences.
- **Quick Stack** deposits and then resupplies in one click.
- **Recipes** sit in the right-hand panel, in place of vanilla crafting. A
  dropdown at the top picks a station (All, Handcraft, Hammer, and every
  crafting bench in the game). Search under the dropdown filters the list by
  name. The list is the same Craft tab that bench would show: known crafts,
  upgrade-only recipes skipped, missing requirements greyed and at the bottom.
  Hammer pieces stay under Hammer. The right side shows the item, its tooltip,
  and the ingredient slots. **Withdraw** pulls those ingredients into your pack;
  a greyed recipe still takes whatever is there. Hover an ingredient to see
  have / need. Vanilla crafting comes back when you leave Njord, including Tab
  inventory, handcraft, and every workbench.
- **The cog** opens client Preferences. **Settings** holds ignore favourite
  items on deposit, the Deposit+Resupply hotkey, and **Reorganize**. **Resupply**
  has its own search and the list of items to keep in your pack, with a
  quantity for each.
- While in range of Njord (the same radius as the network), the hotkey deposits
  and then resupplies without talking to him.
- Click the search box to type. It keeps focus, so E does not close the panel.
- Hold use, the same as a vanilla chest, to stack everything that will fit.
- **From time to time** Njord merges leftover piles of the same item in nearby
  chests so they occupy as few slots as they can. Full stacks stay put. Chests
  someone already has open are left alone. The interval is in config, and a
  **Reorganize** button in Preferences runs the same tidy immediately.

Chests behind a ward you cannot pass, private chests that are not yours, chests
someone else already has open, other keepers, and incinerators are left
out of the scan.

## Configuration

`BepInEx/config/com.gitmcp.njord.cfg` is written on first launch. The
server's values for radius, line of sight, the hotbar, and reorganize are
authoritative and are synced to clients. Favourites, Resupply, and the
deposit-skip toggle are **client-only** and stay on that machine.

| Setting | Default | Description |
| --- | --- | --- |
| `Njord / Radius` | `15` | How far, in metres, a container is still part of Njord's network. |
| `Njord / RequireLineOfSight` | `false` | Only include chests he can see. Off so a chest in the next room still counts. |
| `Njord / DepositHotbar` | `false` | Also deposit the first inventory row. |
| `Njord / Reorganize` | `true` | Merge leftover piles of the same item so they use as few chest slots as possible. |
| `Njord / ReorganizeInterval` | `60` | Seconds between tidy passes (15–1800). |
| `Client / DepositSkipFavourites` | `true` | Ignore favourite items on deposit. Also set from the cog. |
| `Client / RestockHotkey` | *(none)* | In range of Njord, Deposit then Resupply. Bound from the cog. |
| `Client / Favourites` | *(empty)* | Starred item keys. Edited from the item list or from pack slots. |
| `Client / Resupply` | *(empty)* | Item keys and counts for the Resupply button. Edited from the cog. |

## How it works

Valheim chests already sync through a ZDO: the owner writes the inventory blob,
everyone else loads it. Opening a chest is an RPC that hands ownership to the
player, which is why two people cannot rummage the same box at once.

Njord does not copy those stacks into a fake inventory. He reads the chests that
are already loaded around him, lists the live `ItemData`, and when you take or
deposit he calls `Inventory.MoveItemToThis` after `ZNetView.ClaimOwnership`,
the same claim Take All uses. The item changes chest only once, on the peer that
now owns that ZDO. Talking to him does not lock him to one player, and does not
steal his ZDO: several people can have the panel open at once. Nearby chests
that someone already has open in the vanilla GUI are still left out of the scan.

When nobody is rummaging a chest, Njord periodically merges leftover piles of
the same item so they take as few slots as they can. Only the peer that owns
his ZDO does that pass, so two clients do not tidy the same hall at once.

Walking away still closes the panel, because the game still treats talking to
Njord as having a container open.
