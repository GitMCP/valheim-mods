# Changelog

## 1.1.0

Favourites, a client preferences tab, and Resupply. Star an item in the hub list
to pin it. The Favourites category and the star filter show only those items.
The cog opens client-only settings: skip favourites when depositing everything,
a Deposit+Resupply hotkey used while in range of a hub, and a Resupply list
(titled Resupply) of items and counts to keep in the pack. Recipe lists known
crafts and withdraws their ingredients when the hub has enough.

## 1.0.0

First release as Storage Hub. A black metal chest that opens a combined view of
nearby containers, with search, categories, sorting, a slot meter, grouped stacks,
shift-click to take a chosen amount, and drag from the backpack onto the panel to
store. Costs 10 Fine wood, 2 Iron, and 2 Surtling cores. The hub panel sits in
the center of the screen, between the backpack and the crafting column. The item
list mouse-wheels at the same pace as crafting-station recipes.

## 0.1.0

First build, as Gateway Chest. A hammer piece cloned from the reinforced chest.
